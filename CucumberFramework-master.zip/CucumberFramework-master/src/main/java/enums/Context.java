package enums;

public enum Context {
	PRODUCT_NAME;
}