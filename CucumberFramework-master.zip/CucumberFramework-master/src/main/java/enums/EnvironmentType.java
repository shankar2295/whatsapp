package enums;

public enum EnvironmentType {
	LOCAL,
	REMOTE,
}
